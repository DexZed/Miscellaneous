

const About = () => {
    return (
        <div>
            <h2>About us</h2>
            <p>Everything you want to know</p>
        </div>
    );
};

export default About;