

const Support = () => {
    return (
        <div>
            <h3>Support session coming soon</h3>
        </div>
    );
};

export default Support;