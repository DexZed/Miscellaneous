
const Session = () => {
    return (
        <div>
            <h2>Conceptual Session</h2>
        </div>
    );
};

export default Session;