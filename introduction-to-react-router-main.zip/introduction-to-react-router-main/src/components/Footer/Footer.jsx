

const Footer = () => {
    return (
        <div>
            <p><small>Thank  you for visiting our website</small></p>
        </div>
    );
};

export default Footer;