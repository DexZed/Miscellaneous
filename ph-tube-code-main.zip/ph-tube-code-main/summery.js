/**
 * 1. load and display data initially
 * 2. on Click load and display data
 * 3. Complex object accessing
 * 4. toggle active class functionality
 * 5. search functionality
 * 6. load and display single data
 * 7. display data in a modal
 * 8. load and display single category data
 * 9. Conditional rendering if array dont have any data
 * 10.Conditional Rendering:: if a value empty
 * 11.Conditional Rendering:: if a value length is zero
 *
 *
 *
 *
 *
 *
 *
 */
