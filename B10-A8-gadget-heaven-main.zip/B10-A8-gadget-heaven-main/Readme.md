## Private For your Assignment

you have to create private repo in our Google Classroom . here is the Link

# [https://classroom.github.com/a/_zIUwTOu](https://classroom.github.com/a/_zIUwTOu)



figma link: https://www.figma.com/design/qr7hizhQyfmitEimBC6blK/Assignment-8?node-id=0-1&node-type=canvas&t=7Sr6v8i3wIN015u6-0



## follow requerment pdf 
