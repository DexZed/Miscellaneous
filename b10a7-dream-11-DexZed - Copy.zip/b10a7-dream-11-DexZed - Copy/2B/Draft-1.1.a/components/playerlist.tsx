import React, { useEffect, useState, useRef } from "react";
import playersData from "../Data/player.json";
import PlayerCard from "./PlayerCard";
import { usePlayerContext } from "./Godseye";

interface Player {
  playerId: number;
  name: string;
  country: string;
  image: string;
  role: string;
  battingType: string;
  bowlingType: string;
  biddingPrice: number;
}

const PlayerList: React.FC = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);

  const playersPerPage = 6;
  const generatorRef = useRef<Generator<Player[], void, unknown> | null>(null);

  const { addPlayer } = usePlayerContext(); // Use context to add players

  function* paginate(arr: Player[], size: number) {
    let index = 0;
    while (index < arr.length) {
      yield arr.slice(index, index + size);
      index += size;
    }
  }

  const loadPlayers = async () => {
    if (generatorRef.current) {
      setIsLoading(true);
      const nextPlayers = generatorRef.current.next().value;
      if (nextPlayers) {
        setPlayers((prev) => {
        
          const newPlayers = nextPlayers.filter(
            (newPlayer) => !prev.some((p) => p.playerId === newPlayer.playerId)
          );
          return [...prev, ...newPlayers];
        });
      } else {
        setHasMore(false);
      }
      setIsLoading(false);
    }
  };

  useEffect(() => {
    generatorRef.current = paginate(playersData, playersPerPage);
    loadPlayers();
  }, []);

  return (
    <div>
      <div className="player-list grid grid-cols-1 md:grid-cols-3 gap-5 mx-32 md:mx-auto">
        {players.map((player) => (
          <PlayerCard
            key={player.playerId}
            {...player}
            onAddPlayer={addPlayer}
          />
        ))}
      </div>

      {hasMore ? (
        <button className="btn m-3" onClick={loadPlayers} disabled={isLoading}>
          {isLoading ? "Loading..." : "Load More"}
        </button>
      ) : (
        <button className="btn m-3" disabled={true}>No more players....</button>
      )}
    </div>
  );
};

export default PlayerList;
