import React from "react";
import { usePlayerContext } from "./Godseye";

interface SelectedProps {
  setShowPlayers: (show: boolean) => void; // Prop to toggle view
}

const AddedPlayers: React.FC<SelectedProps> = ({ setShowPlayers }) => {
  const { addedPlayers, removePlayer } = usePlayerContext(); // Access players and remove function

  return (
    <div className="my-5 min-h-screen">
      {addedPlayers.length > 0 ? (
        addedPlayers.map((player) => (
          <div
            key={player.playerId}
            className="card lg:card-side bg-base-100 shadow-xl my-5"
          >
            <figure>
              <img src={player.image} alt={player.name} className="w-1/4 place-self-start md:-translate-x-52 " />
            </figure>
            <div className="card-body">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:mt-5">
                <div className="flex flex-col md:-translate-x-92 ">
                  <h2 className="card-title place-self-center md:place-self-start">
                    {player.name}
                  </h2>
                  <p className="place-self-center md:place-self-start">
                    {player.role}
                  </p>
                </div>
                <div className="card-actions place-self-center md:justify-end">
                <button
                  className="btn btn-error btn-outline"
                  onClick={() => removePlayer(player.playerId)}
                >
                  Remove Player
                </button>
              </div>
              </div>
              
            </div>
          </div>
        ))
      ) : (
        <div className="flex">
          <button className="skin btn join-item" onClick={() => setShowPlayers(true)}>Add Players</button>
        </div>
        
      )}
    </div>
  );
};

export default AddedPlayers;
