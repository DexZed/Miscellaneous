// General react imports
import React from "react";
import { usePlayerContext } from "./Godseye";
import './styles.scss';
//Banner component

const Banner: React.FC = () => {

  const { addCoins } = usePlayerContext();
  const handleCoin = () => {
    addCoins(10000000000); 
  };

  return (
    <div
      className="hero h-96 rounded-[50px] bg-black mt-5"
      style={{
        backgroundImage:
          "url(../src/assets/bg-shadow.png)",
  
      }}
    >
      <div className="hero-overlay bg-opacity-10 rounded-[50px]"></div>
      <div className="hero-content text-neutral-content text-center">
        <div className="max-w-md">
          <h1 className="mb-5 text-3xl font-bold">
            <img src="../src/assets/banner-main.png" alt="" className="w-1/4 place-self-center mb-2"/>
            Assemble Your Ultimate Dream 11 Cricket Team
          </h1>
          <p className="mb-5">Beyond Boundaries Beyond Limits</p>
          
          <button className="skin btn  text-black outline outline-[#E7FE29] outline-offset-2 outline-2" onClick={handleCoin}>Claim Free Credit</button>


          
        </div>
      </div>
    </div>
  );
};
export default Banner;
