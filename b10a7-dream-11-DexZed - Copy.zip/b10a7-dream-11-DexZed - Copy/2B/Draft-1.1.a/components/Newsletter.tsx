import React from "react";

//newsletter component

const Newsletter: React.FC = () => {
  return (
    <div
      className="hero rounded-3xl"
      style={{
        backgroundImage: "url(../src/assets/bg-shadow.png)",
      }}
    >
      <div className="hero-overlay bg-opacity-10 rounded-3xl outline outline-offset-4 outline-lime-700"></div>
      <div className="hero-content text-neutral-content text-center">
        <div className="max-w-md">
          <h1 className="mb-5 text-3xl font-bold text-black ">
            Subcribe to our newsletter
          </h1>
          <p className="mb-5 text-black">
            Get the latest updates right in your inbox
          </p>
          <div className="flex gap-5">
          <input
            type="email"
            className="input input-bordered input-accent w-full max-w-xs"
            placeholder="Enter your email"
          />
          <button className="btn btn-accent btn-outline">Subcribe</button>
          </div>
          
        </div>
      </div>
    </div>
  );
};

export default Newsletter;
