import React from "react";
import "./styles.scss";

//footer component

const Footer: React.FC = () => {
  return (
    <div className="ft-ctn mt-5">
      <footer className="footer bg-black text-base-content p-10">
        <div className="flex">
          <img src="../src/assets/logo-footer.png" alt="footer logo" />
          <h6 className="text-white ">
            <span className="text-xl footer-title">About Us</span>
            <br /><br />
            We are a passionate team <br />
            dedicated to providing <br />
            the best services
          </h6>
        </div>
        <nav>
          <h6 className="footer-title text-white">Services</h6>
          <a className="link link-hover text-white">Branding</a>
          <a className="link link-hover text-white">Design</a>
          <a className="link link-hover text-white">Marketing</a>
          <a className="link link-hover text-white">Advertisement</a>
        </nav>
        <form>
          <h6 className="footer-title text-white">Subscribe</h6>
          <p className="link link-hover text-slate-400 ">
            Subscribe to get the latest updates right in your inbox
          </p>
          <fieldset className="form-control w-80">
            <label className="label">
              <span className="label-text text-white">
                Enter your email address
              </span>
            </label>
            <div className="join">
              <input
                type="text"
                placeholder="Enter Your email"
                className="input input-bordered join-item"
              />
              <button className="btn btn-primary join-item">Subscribe</button>
            </div>
          </fieldset>
        </form>
      </footer>
    </div>
  );
};

export default Footer;
