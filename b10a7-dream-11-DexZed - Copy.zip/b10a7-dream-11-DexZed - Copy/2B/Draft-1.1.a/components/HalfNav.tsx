import React, { useState } from "react";
import Available from "./PlayerList";
import Selected from "./SelectedPlayers";
import { usePlayerContext } from "./Godseye";
import './styles.scss';
const Switch: React.FC = () => {
  const [showPlayers, setShowPlayers] = useState(true); 
  const { addedPlayers } = usePlayerContext(); 
  return (
    <>
    <div className="flex justify-items justify-around m-5">
      <h2 className="text-2xl font-bold">Available Players</h2>
      <div className="join join-vertical join-horizontal">
        <button className="skin btn join-item" onClick={() => setShowPlayers(true)}>Available</button>
        <button className="btn join-item" onClick={() => setShowPlayers(false)}>Selected ({addedPlayers.length}/6)</button> 
      </div>
    </div>
    {showPlayers ? <Available /> : <Selected setShowPlayers={setShowPlayers} />}
    </>
  );
};
export default Switch;