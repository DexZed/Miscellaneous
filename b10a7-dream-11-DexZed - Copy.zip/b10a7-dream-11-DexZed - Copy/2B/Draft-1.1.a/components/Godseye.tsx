import React, { createContext, useContext, useState, ReactNode } from "react";
import { toast } from "react-toastify";
// Player interface
interface Player {
  playerId: number;
  name: string;
  country: string;
  image: string;
  role: string;
  battingType: string;
  bowlingType: string;
  biddingPrice: number;
}

// Context value interface
interface PlayerContextType {
  addedPlayers: Player[];
  balance: number;
  addPlayer: (player: Player) => void;
  removePlayer: (playerId: number) => void;
  addCoins: (amount: number) => void;
}

// Create the context
const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

// Custom hook to use the context
export const usePlayerContext = () => {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error("usePlayerContext must be used within a PlayerProvider");
  }
  return context;
};

// Provider component
 const PlayerProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [addedPlayers, setSelected] = useState<Player[]>([]);
  const [balance, setBalance] = useState<number>(0); 

  const addCoins = (amount: number) => {
    setBalance((prev) => prev + amount); 
    toast.success("Coins added successfully!");
  };

  const addPlayer = (player: Player) => {
    if (addedPlayers.length >= 6) {
      toast.error("Cannot add more than 6 players!");
      return;
    }

    if (addedPlayers.some((p) => p.playerId === player.playerId)) {
      toast.warning("Player already selected!");
      return;
    }

    if (balance < player.biddingPrice) {
      toast.error("Not enough coins to add this player.");
      return;
    }

    setSelected((prev) => [...prev, player]);
    setBalance((prev) => prev - player.biddingPrice);
    toast.success("Player added successfully!");
  };

  const removePlayer = (playerId: number) => {
    const removePlayer = addedPlayers.find((p) => p.playerId === playerId);
    if (removePlayer) {
      setSelected((prev) => prev.filter((p) => p.playerId !== playerId));
      setBalance((prev) => prev + removePlayer.biddingPrice); 
      toast.info("Player removed successfully!");
    }
  };

  return (
    <PlayerContext.Provider value={{ addedPlayers, balance, addPlayer, removePlayer,addCoins}}>
      {children}
    </PlayerContext.Provider>
  );
};
export default PlayerProvider;