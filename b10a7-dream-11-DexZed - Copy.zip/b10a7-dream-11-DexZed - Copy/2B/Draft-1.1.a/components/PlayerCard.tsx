import React from "react";
import "./styles.scss";
import { usePlayerContext } from "./Godseye";


interface Player {
  playerId: number;
  name: string;
  country: string;
  image: string;
  role: string;
  battingType: string;
  bowlingType: string;
  biddingPrice: number;
  onAddPlayer: (player: Player) => void;
}

//player card component

const PlayerCard: React.FC<Player> = ({ ...Player }) => {
  const {
    name,
    country,
    image,
    role,
    biddingPrice,
    onAddPlayer,
    battingType,
    bowlingType,
  } = Player;
  const { addedPlayers } = usePlayerContext();
  return (
    <div className="card bg-base-100 w-96 shadow-2xl">
          <figure className="px-5 pt-5">
            <img
              src={image}
              alt={name}
              className="rounded-xl aspect-auto h-52"
            />
          </figure>
          <div className="card-body ">
            <h2 className="card-title">
              <img
                src="../src/assets/person.png"
                alt="player icon"
                className="w-5"
              />
              {name}
            </h2>
            <div className="flex">
              <p className="flex gap-1 text-slate-400">
                <img
                  src="../src/assets/finish.png"
                  alt="flag icon"
                  className="w-5"
                />
                {country}
              </p>
              <p className="bg-slate-200 p-1 rounded-lg">{role}</p>
            </div>
            <hr />
            <h3 className="text-left font-bold">Rating</h3>
            <div className="grid grid-cols-2 gap-5">
              <p className="place-self-start font-bold text-sm">
                {battingType}
              </p>
              <p className="place-self-end">{bowlingType}</p>
              <p className="place-self-start font-bold text-sm">
                Price : ${biddingPrice.toLocaleString()}
              </p>
              <div className="card-actions">
                <button className="btn" onClick={()=>onAddPlayer(Player)} disabled={addedPlayers.length > 6}>Choose Player</button>
              </div>
            </div>
          </div>
        </div>
  );
};

export default PlayerCard;
