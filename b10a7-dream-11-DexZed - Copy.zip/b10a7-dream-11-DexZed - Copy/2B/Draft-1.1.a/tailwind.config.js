/** @type {import('tailwindcss').Config} */
import daisyui from "daisyui"
module.exports = {
  content: [
    './index.html',         // If applicable
    './src/**/*.{js,jsx,ts,tsx}', // For React components
    './src/**/*.{html,css,scss}',
    './components/**/*.{js,jsx,ts,tsx}', // For any other style files
  ],
  theme: {
    extend: {},
  },
  plugins: [daisyui,],
}
