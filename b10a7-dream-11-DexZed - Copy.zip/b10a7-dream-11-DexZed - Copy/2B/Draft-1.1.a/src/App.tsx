import "./App.css";
import Nav from "../components/coolnav";
import GodsEye from "../components/Godseye";
import Hero from "../components/Banner";
import Switch from "../components/HalfNav";
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import News from '../components/Newsletter';
import Ft from '../components/feet';
function App() {
  return (
    <>
      <GodsEye>
      <ToastContainer position="top-center" autoClose={2000} />
        <Nav></Nav>
        <Hero></Hero>
        <Switch></Switch>
      </GodsEye>
      <News />
      <Ft />
    </>
  );
}

export default App;
