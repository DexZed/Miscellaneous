class DataHandler {
  constructor() {
    this.data = [];
    this.filteredData = [];
  }

  async fetchData() {
    try {
      const response = await fetch(
        "https://openapi.programming-hero.com/api/peddy/pets"
      );
      const jsonResponse = await response.json();
      this.data = jsonResponse.pets;
      this.filteredData = [...this.data];
      this.renderCategories(this.filteredData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  // Method to filter and render pets by category
  filterByCategory(category) {
    if (category === "All") {
      this.filteredData = [...this.data];
    } else {
      this.filteredData = this.data.filter((pet) => pet.category === category);
    }
    this.renderCategories(this.filteredData);
  }

  // Method to sort pets by price in descending order
  sortByPrice() {
    const sortedPets = [...this.filteredData].sort((a, b) => b.price - a.price);
    this.renderCategories(sortedPets, false);
  }

  // Method to render pets
  async renderCategories(pets, showProgressBar = true) {
    if (showProgressBar) {
      await this.showProgress("category-container");
    }

    const container = document.getElementById("category-container");
    container.innerHTML = "";
    container.classList =
      "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10 my-2";

    if (pets.length === 0) {
      this.errorSection();
    } else {
      let fragment = document.createDocumentFragment();
      pets.forEach((pet) => {
        const card = document.createElement("div");
        card.classList.add("item", "border-2", "rounded-xl", "p-5");
        card.innerHTML = `
                <img src="${pet.image}" alt="${pet.pet_name}" width="100%" style="object-fit: cover; aspect-ratio: 16/9;border-radius: 10px">
                <h3 class="text-xl font-bold">${pet.pet_name}</h3>
                <p class="text-sm text-gray-500 flex"><img src="./icons/collection.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">Breed: ${pet.breed}</p>
                <p class="text-sm text-gray-500 flex"><img src="./icons/birthday-cake.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">Birth: ${pet.date_of_birth}</p>
                <p class="text-sm text-gray-500 flex"><img src="./icons/gender.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">Gender: ${pet.gender}</p>
                <p class="text-sm text-gray-500 flex"><img src="./icons/dollar.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">Price: ${pet.price} $</p>
                <div class="border-2 rounded-3xl my-2"></div>
                <div class="flex justify-around flex-wrap gap-1">
                    <button type="button" data-id="${pet.petId}" class="like-btn btn btn-outline btn-info btn-sm"><img src="./icons/like.png" alt="" class="w-[20px] h-[20px] place-self-center"></button>
                    <button id="adp" type="button" data-id="${pet.petId}" onclick="app.adoptionModal()" class="adopt-btn btn btn-outline btn-accent btn-sm">Adopt</button>
                    <button type="button" data-id="${pet.petId}" class="details-btn btn btn-outline btn-primary btn-sm">Details</button>
                </div>
            `;
        fragment.appendChild(card);
      });
      container.appendChild(fragment);
      this.attachLikeButtonListeners();
      this.attachDetailsButtonListeners();
    }
  }

  // Method to show and animate the progress bar
  showProgress(containerId) {
    return new Promise((resolve) => {
      const container = document.getElementById(containerId);
      container.innerHTML = "";

      const progressBar = document.createElement("div");
      progressBar.classList.add(
        "radial-progress",
        "bg-primary",
        "text-primary-content",
        "border-primary",
        "border-4",
        "ml-32",
        "sm:ml-[650px]",
        "sm:my-56",
        "my-32"
      );
      progressBar.setAttribute("role", "progressbar");
      progressBar.style.setProperty("--value", "0");

      const progressText = document.createElement("span");
      progressText.textContent = "0%";

      progressBar.appendChild(progressText);
      container.appendChild(progressBar);

      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += 5;
        progressBar.style.setProperty("--value", progress);
        progressText.textContent = `${progress}%`;

        if (progress >= 100) {
          clearInterval(progressInterval);

          setTimeout(() => {
            resolve();
          }, 500);
        }
      }, 100);
    });
  }

  attachLikeButtonListeners() {
    const likeButtons = document.querySelectorAll(".like-btn");

    likeButtons.forEach((button) => {
      button.addEventListener("click", (event) => {
        const petId = event.target.closest("button").getAttribute("data-id");

        this.addToLikedPets(petId);
      });
    });
  }
  // Method to add the clicked pet's image to the <aside> container
  addToLikedPets(petId) {
    const likedPet = this.filteredData.find((pet) => pet.petId == petId);

    if (likedPet) {
      const stacksContainer = document.querySelector(".stacks");

      if (!stacksContainer.querySelector(`img[alt="${likedPet.pet_name}"]`)) {
        const imgElement = document.createElement("div");
        imgElement.classList.add(
          "stacks-style",
          "border-2",
          "rounded-md",
          "p-1",
          "my-1"
        );
        imgElement.innerHTML = `
          <img src="${likedPet.image}" alt="${likedPet.pet_name}" width="100%" class="object-cover rounded-md">
        `;

        stacksContainer.appendChild(imgElement);
      }
    }
  }

  // Method to open the modal when the adopt button is clicked
  adoptionModal() {
    const adpMdl = document.querySelectorAll(".adopt-btn");
    const modal = document.getElementById("my_modal_2");
    const cd = document.getElementById("countdown");
    const colors = ["red", "orange", "green"];

    adpMdl.forEach((button) => {
      button.addEventListener("click", (event) => {
        modal.showModal();

        event.target.disabled = true;

        let countdown = 3;

        const timerInterval = setInterval(() => {
          cd.textContent = countdown;
          cd.style.color = colors[countdown - 1];
          countdown--;

          if (countdown < 0) {
            clearInterval(timerInterval);
            modal.close();
          }
        }, 1000);
      });
    });
  }
  // Method to attach event listener to details button
  attachDetailsButtonListeners() {
    const details = document.querySelectorAll(".details-btn");

    details.forEach((button) => {
      button.addEventListener("click", (event) => {
        const petId = event.target.closest("button").getAttribute("data-id");
        this.showDetailsModal(petId);
      });
    });
  }

  // Method to show dynamic details modal when details is clicked
  showDetailsModal(petId) {
    const detailsMdl = document.getElementById("my_modal_1");

    detailsMdl.innerHTML = "";

    const pet = this.filteredData.find((pet) => pet.petId == petId);

    if (pet) {
      const mdl = document.createElement("div");
      mdl.classList.add("modal-box");
      mdl.innerHTML = `
      <div class="flex justify-center">
        <img src="${pet.image}" alt="${pet.pet_name}" class="object-cover rounded-md">
      </div>
    
      <h3 class="text-xl font-bold">${pet.pet_name}</h3>
      <div class="border-2 rounded-3xl "></div>
      <div class="grid grid-cols-2 p-3 gap-2">
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/collection.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1"> 
          Breed: ${pet.breed}
        </p>
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/birthday-cake.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">
          Birth: ${pet.date_of_birth}
        </p>
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/gender.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1"> 
          Gender: ${pet.gender}
        </p>
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/dollar.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1"> 
          Price: ${pet.price} $
        </p>
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/injection.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1"> 
          Vaccinated status: ${pet.vaccinated_status}
        </p>
      </div>
      <div class="border-2 rounded-3xl "></div>
      <div class="flex flex-col gap-2">
        <h3 class="text-md font-bold">Details Information</h3>
        <p class="text-sm text-gray-500 text-ellipsis">${pet.pet_details}</p>
      </div>
      <div class="modal-action sticky bottom-0">
        <form method="dialog" class="modal-backdrop">
          <button class="btn btn-outline btn-success">Close</button>
        </form>
      </div>
    `;

      detailsMdl.appendChild(mdl);

      detailsMdl.showModal();
    }
  }

  // To display nothing section when no catagories are available
  errorSection() {
    const errorSection = document.getElementById("category-container");
    errorSection.classList = "";
    errorSection.innerHTML = "";
    const errorDiv = document.createElement("div");
    errorDiv.classList.add(
      "hero",
      "bg-base-200",
      "col-span-full",
      "sm:w-[1200px]",
      "p-2",
      "m-2",
      "rounded-3xl"
    );
    errorDiv.innerHTML = `
      <div class="hero-content text-center h-[500px]">
    <div class="max-w-md flex flex-col">
    <img src="./images/error.webp" alt="" class="w-[100px] h-[100px] place-self-center">
      <h1 class="text-5xl font-bold">No Information Available</h1>
      <p class="py-6">
       It is a long established fact that a reader will be distracted by the readable content of a page when looking at 

its layout. The point of using Lorem Ipsum is that it has a.
      </p>
      
    </div>
  </div>
    `;
    errorSection.appendChild(errorDiv);
  }
}

const app = new DataHandler();
app.fetchData();

document.querySelectorAll(".filter-btn").forEach((button) => {
  button.addEventListener("click", (event) => {
    document.querySelectorAll(".filter-btn").forEach((btn) => {
      btn.classList.add("btn-outline");
    });

    const clickedButton = event.target;

    clickedButton.classList.remove("btn-outline");
    const category = event.target.getAttribute("data-category");
    app.filterByCategory(category);
  });
});

// Event Listener for Sort By Price Button
document.getElementById("sort-btn").addEventListener("click", () => {
  app.sortByPrice();
});
