function openModal() {
  const modal = document.getElementById("my_modal_2");
  const cd = document.getElementById("countdown");
  const adp = document.getElementById("adp");
  let countdown = 3;
  const colors = ["red", "orange", "green"];
  // Show the modal
  modal.showModal();
  adp.disabled = true;
  // Update the countdown every second
  const timerInterval = setInterval(() => {
    countdown--;
    cd.textContent = countdown;
    cd.style.color = colors[countdown];

    // When countdown reaches 0, close the modal
    if (countdown === 0) {
      clearInterval(timerInterval);
      modal.close();
    }
  }, 1000);
}
