class DataHandler {
  constructor() {
    this.data = [];
    this.filteredData = []; // Store currently filtered data
  }

  async fetchData() {
    try {
      const response = await fetch(
        "https://openapi.programming-hero.com/api/peddy/pets"
      );
      const jsonResponse = await response.json();
      this.data = jsonResponse.pets; // Save the pets data
      this.filteredData = [...this.data]; // Initially, set filteredData to all pets
      this.renderCategories(this.filteredData); // Render all categories initially
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  // Method to filter and render pets by category
  filterByCategory(category) {
    if (category === "All") {
      this.filteredData = [...this.data]; // Show all if category is 'All'
    } else {
      this.filteredData = this.data.filter((pet) => pet.category === category);
    }
    this.renderCategories(this.filteredData); // Show only filtered pets
  }

  // Method to sort pets by price in descending order
  sortByPrice() {
    const sortedPets = [...this.filteredData].sort((a, b) => b.price - a.price);
    this.renderCategories(sortedPets, false); // Render sorted pets by price
  }

  // Method to render pets
  async renderCategories(pets, showProgressBar = true) {
    if (showProgressBar) {
      await this.showProgress('category-container'); // Show progress only if the flag is true
  }


    const container = document.getElementById("category-container");
    container.innerHTML = ""; // Clear previous content
    container.classList="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10 my-2";
    // Check if there are any pets in the array
    if (pets.length === 0) {
        this.errorSection(); // Show error section if no pets
    } else {
        // Render categories
        let fragment = document.createDocumentFragment();
        pets.forEach((pet) => {
            const card = document.createElement("div");
            card.classList.add("item", "border-2", "rounded-xl", "p-5");
            card.innerHTML = `
                <img src="${pet.image}" alt="${pet.pet_name}" width="100%" style="object-fit: cover; aspect-ratio: 16/9;border-radius: 10px">
                <h3 class="text-xl font-bold">${pet.pet_name}</h3>
                <p class="text-sm text-gray-500 flex"><img src="./icons/collection.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">Breed: ${pet.breed}</p>
                <p class="text-sm text-gray-500 flex"><img src="./icons/birthday-cake.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">Birth: ${pet.date_of_birth}</p>
                <p class="text-sm text-gray-500 flex"><img src="./icons/gender.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">Gender: ${pet.gender}</p>
                <p class="text-sm text-gray-500 flex"><img src="./icons/dollar.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">Price: ${pet.price} $</p>
                <div class="border-2 rounded-3xl my-2"></div>
                <div class="flex justify-around flex-wrap gap-1">
                    <button type="button" data-id="${pet.petId}" class="like-btn btn btn-outline btn-info btn-sm"><img src="./icons/like.png" alt="" class="w-[20px] h-[20px] place-self-center"></button>
                    <button id="adp" type="button" data-id="${pet.petId}" onclick="app.adoptionModal()" class="adopt-btn btn btn-outline btn-accent btn-sm">Adopt</button>
                    <button type="button" data-id="${pet.petId}" class="details-btn btn btn-outline btn-primary btn-sm">Details</button>
                </div>
            `;
            fragment.appendChild(card);
        });
        container.appendChild(fragment);
        this.attachLikeButtonListeners();
        this.attachDetailsButtonListeners();
    }
}

// Method to show and animate the progress bar
showProgress(containerId) {
  return new Promise((resolve) => {
      const container = document.getElementById(containerId);
      container.innerHTML = ""; // Clear previous content

      // Create the progress bar element
      const progressBar = document.createElement("div");
      progressBar.classList.add("radial-progress", "bg-primary", "text-primary-content", "border-primary", "border-4",'ml-32','sm:ml-[650px]','sm:my-56','my-32');
      progressBar.setAttribute("role", "progressbar");
      progressBar.style.setProperty("--value", "0"); // Start at 0%

      // Create a text node to display the progress percentage inside the progress bar
      const progressText = document.createElement("span");
      progressText.textContent = "0%"; // Initial value

      progressBar.appendChild(progressText); // Append the text to the progress bar
      container.appendChild(progressBar);

      // Simulate the loading progress
      let progress = 0;
      const progressInterval = setInterval(() => {
          progress += 5; // Increase progress by 5% every 100ms
          progressBar.style.setProperty("--value", progress);
          progressText.textContent = `${progress}%`; // Update the progress text

          if (progress >= 100) {
              clearInterval(progressInterval); // Stop the animation at 100%

              // After a small delay, resolve the promise to indicate completion
              setTimeout(() => {
                  resolve(); // Resolve the promise after progress completes
              }, 500); // Optional delay to smooth transition
          }
      }, 100); // 100ms intervals for smooth progress (2 seconds to reach 100%)
  });
}

  attachLikeButtonListeners() {
    const likeButtons = document.querySelectorAll(".like-btn");
    //  Check how many buttons were found.
    // console.log("Like buttons found:", likeButtons.length);

    likeButtons.forEach((button) => {
      button.addEventListener("click", (event) => {
        const petId = event.target.closest("button").getAttribute("data-id");
        // Log petId when button is clicked
        // console.log("Like button clicked for petId:", petId);
        this.addToLikedPets(petId);
      });
    });
  }
  // Method to add the clicked pet's image to the <aside> container
  addToLikedPets(petId) {
    // Find the corresponding pet based on the petId
    const likedPet = this.filteredData.find((pet) => pet.petId == petId);

    if (likedPet) {
      const stacksContainer = document.querySelector(".stacks");

      // Check if the pet's image is already added
      if (!stacksContainer.querySelector(`img[alt="${likedPet.pet_name}"]`)) {
        // Create a new div element for the liked pet's image
        const imgElement = document.createElement("div");
        imgElement.classList.add(
          "stacks-style",
          "border-2",
          "rounded-md",
          "p-1",
          "my-1"
        );
        imgElement.innerHTML = `
          <img src="${likedPet.image}" alt="${likedPet.pet_name}" width="100%" class="object-cover rounded-md">
        `;

        // Append the new div to the stacks container
        stacksContainer.appendChild(imgElement);
      }
    }
  }

  // Method to open the modal when the adopt button is clicked
  adoptionModal() {
    const adpMdl = document.querySelectorAll(".adopt-btn"); // Select buttons by class
    const modal = document.getElementById("my_modal_2");
    const cd = document.getElementById("countdown");
    const colors = ["red", "orange", "green"];

    adpMdl.forEach((button) => {
      button.addEventListener("click", (event) => {
        modal.showModal();

        // Disable the clicked button
        event.target.disabled = true;

        // Reset countdown for every click
        let countdown = 3;

        // Update the countdown every second
        const timerInterval = setInterval(() => {
          cd.textContent = countdown;
          cd.style.color = colors[countdown - 1]; // Use correct index for colors
          countdown--;

          // When countdown reaches 0, close the modal
          if (countdown < 0) {
            clearInterval(timerInterval);
            modal.close();
            // event.target.disabled = false; // Re-enable the button after modal closes
          }
        }, 1000);
      });
    });
  }
  // Method to attach event listener to details button
  attachDetailsButtonListeners() {
    const details = document.querySelectorAll(".details-btn");

    details.forEach((button) => {
      button.addEventListener("click", (event) => {
        const petId = event.target.closest("button").getAttribute("data-id");
        this.showDetailsModal(petId);
      });
    });
  }

  // Method to show dynamic details modal when details is clicked
  showDetailsModal(petId) {
    const detailsMdl = document.getElementById("my_modal_1");

    // Clear previous modal content
    detailsMdl.innerHTML = "";

    // Find the corresponding pet based on the petId
    const pet = this.filteredData.find((pet) => pet.petId == petId);

    // If the pet is found, create the modal body
    if (pet) {
      const mdl = document.createElement("div");
      mdl.classList.add("modal-box");
      mdl.innerHTML = `
      <div class="flex justify-center">
        <img src="${pet.image}" alt="${pet.pet_name}" class="object-cover rounded-md">
      </div>
    
      <h3 class="text-xl font-bold">${pet.pet_name}</h3>
      <div class="border-2 rounded-3xl "></div>
      <div class="grid grid-cols-2 p-3 gap-2">
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/collection.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1"> 
          Breed: ${pet.breed}
        </p>
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/birthday-cake.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1">
          Birth: ${pet.date_of_birth}
        </p>
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/gender.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1"> 
          Gender: ${pet.gender}
        </p>
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/dollar.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1"> 
          Price: ${pet.price} $
        </p>
        <p class="text-sm text-gray-500 flex">
          <img src="./icons/injection.png" alt="" class="w-[10px] h-[10px] place-self-center mx-1"> 
          Vaccinated status: ${pet.vaccinated_status}
        </p>
      </div>
      <div class="border-2 rounded-3xl "></div>
      <div class="flex flex-col gap-2">
        <h3 class="text-md font-bold">Details Information</h3>
        <p class="text-sm text-gray-500 text-ellipsis">${pet.pet_details}</p>
      </div>
      <div class="modal-action sticky bottom-0">
        <form method="dialog" class="modal-backdrop">
          <button class="btn btn-outline btn-success">Close</button>
        </form>
      </div>
    `;

      // Append the modal content directly
      detailsMdl.appendChild(mdl);

      // Show the modal
      detailsMdl.showModal();
    }
  }

  // To display nothing section when no catagories are available
  errorSection() {
    const errorSection = document.getElementById("category-container");
    errorSection.classList = "";
    errorSection.innerHTML = "";
    const errorDiv = document.createElement("div");
    errorDiv.classList.add("hero", "bg-base-200", "col-span-full",'sm:w-[1200px]','p-2','m-2','rounded-3xl');
    errorDiv.innerHTML = `
      <div class="hero-content text-center h-[500px]">
    <div class="max-w-md flex flex-col">
    <img src="./images/error.webp" alt="" class="w-[100px] h-[100px] place-self-center">
      <h1 class="text-5xl font-bold">No Information Available</h1>
      <p class="py-6">
       It is a long established fact that a reader will be distracted by the readable content of a page when looking at 

its layout. The point of using Lorem Ipsum is that it has a.
      </p>
      
    </div>
  </div>
    `;
    errorSection.appendChild(errorDiv);
  }
}

// Initialize DataHandler and fetch data
const app = new DataHandler();
app.fetchData();
// Event Listener for Filter Buttons
document.querySelectorAll(".filter-btn").forEach((button) => {
  button.addEventListener("click", (event) => {
    document.querySelectorAll(".filter-btn").forEach((btn) => {
      btn.classList.add("btn-outline");
    });

    // Get the clicked button
    const clickedButton = event.target;

    // Add the active class and remove the btn-outline class to the clicked button
    clickedButton.classList.remove("btn-outline");
    const category = event.target.getAttribute("data-category");
    app.filterByCategory(category);
  });
});

// Event Listener for Sort By Price Button
document.getElementById("sort-btn").addEventListener("click", () => {
  app.sortByPrice(); // Sort and display pets by price when clicked
});
