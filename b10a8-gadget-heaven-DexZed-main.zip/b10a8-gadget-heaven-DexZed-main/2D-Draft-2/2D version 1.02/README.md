
# Gadget Works

E-commerce platform for buying cutting edge tech.


## Live Website Link
- [brain-rot-course.surge.sh](http://brain-rot-course.surge.sh)



## Documentation

- **[Requirement Documentation](https://github.com/programming-hero-web-course2/b10a8-gadget-heaven-DexZed/blob/main/2D-Draft-2/2D%20version%201.02/requirements.pdf)**
## React Fundamentals Used
This project demonstrates the use of key React concepts, including:
- **useState** – for managing state.
- **useEffect** – for side effects and data fetching.
- **Context API** – for global state management across components.
- **Components** – modular, reusable UI components.
- **JSX (TSX)** – with TypeScript integration for typed JSX.
- **Props** – for passing data between components.
- **State** – for local component data management.
## Data Handling and Management
- **Context API**: Used to manage and share the application’s state, such as cart and wishlist data, across components without prop drilling.

## Key Features
1. **Category-Based Product Filtering**: Allows users to filter products by category.
2. **Cart and Wishlist Management**: Users can add or remove items from the cart and wishlist with one click.
3. **Sort by Price**: Enables sorting items in the cart by descending price.
4. **Cart and Wishlist Indicator in Navbar**: Displays the current number of items in the cart and wishlist directly in the navbar.
5. **Custom Alerts and Modal for Purchases**:
   - Custom alerts notify users of actions like adding to the cart or wishlist.
   - A modal confirms purchase completion.
6. **Routing**: Provides seamless navigation between Home, Statistics, Dashboard, About Me, and a custom 404 Page for unmatched routes.


## Feedback

If you have any feedback, please reach out to us 

---

**Note**: The **About Me** section is included as a unique requirement, meeting the project’s specifications.
