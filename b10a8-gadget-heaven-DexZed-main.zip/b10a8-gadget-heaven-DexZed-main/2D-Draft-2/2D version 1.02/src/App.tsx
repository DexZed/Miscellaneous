import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Footer from "./components/Footer";
import Banner from "./components/Banner";
import Nav from "./components/nav";
import Pain from "./components/Pain";
import Dashboard from "./routes/Dashboard-page";
import ErrorPage from "./routes/error-page";
import { GlobalProvider } from "./components/Global";
import Head from "./components/Head";
import { HelmetProvider } from "react-helmet-async";
import Unique from "./routes/Unique";

const router = createBrowserRouter([
  {
    path: "/",
    element: (
      <>
        <Head />
        <Nav />
        <Banner />
        <Pain />
        <Footer />
      </>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: "/dashboard",
    element: (
      <>
        <Head />
        <Nav />
        <Dashboard />
        <Footer />
      </>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: "/about",
    element: (
      <>
        <Head />
        <Nav />
        <Unique/>
        <Footer />
      </>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: "*",
    element: <ErrorPage />,
  },
]);

function App() {
  return (
    <HelmetProvider>
      <GlobalProvider>
        <RouterProvider router={router} />
      </GlobalProvider>
    </HelmetProvider>
  );
}

export default App;
