import React, { useState } from "react";
import Cart from "../components/Cart";
import WishList from "../components/WishList";

const Dashboard: React.FC = () => {
    const [activeComponent, setActiveComponent] = useState<'cart' | 'wishlist'>('cart');

    const handleSelect = (component: 'cart' | 'wishlist') => {
        setActiveComponent(component);
      };
  return (
    <>
      <div className="dashboard">
      <div className="hero bg-[#9538E2]">
        <div className="hero-content text-center">
          <div className="max-w-md">
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            <p className="py-6 text-white">
              Explore the latest gadgets that will take your experience to the
              next level. From smart devices to the coolest accessories, we have
              it all!
            </p>
            <button
              onClick={() => handleSelect('cart')}
              className={`btn btn-neutral btn-outline bg-white text-black rounded-full mr-2 w-32 ${
                activeComponent === 'cart' ? 'border-2 border-black' : ''
              }`}
            >
              Cart
            </button>
            <button
              onClick={() => handleSelect('wishlist')}
              className={`btn btn-info bg-black btn-outline text-black rounded-full w-32 ${
                activeComponent === 'wishlist' ? 'border-2 border-black' : ''
              }`}
            >
              Wishlist
            </button>
          </div>
        </div>
      </div>

      {/* Conditionally render based on activeComponent */}
      {activeComponent === 'cart' && <Cart />}
      {activeComponent === 'wishlist' && <WishList />}
    </div>
    </>
  );
};

export default Dashboard;
