import React from "react";
import { NavLink } from "react-router-dom";

const Unique: React.FC = () => {
  return (
    <div
      className="hero min-h-screen"
      style={{
        backgroundImage: "url(./images/bg-about.jpg)",
      }}
    >
      <div className="hero-overlay bg-opacity-60"></div>
      <div className="hero-content text-neutral-content text-center">
        <div className="max-w-md">
          <h1 className="mb-5 text-5xl font-bold font-mono">About Me</h1>
          <p className="mb-5">
            Hello! I'm a <strong>Software Engineer</strong> and{" "}
            <em>Web Developer</em> with a strong passion for creating
            innovative, efficient, and scalable solutions.With a major focus on{" "}
            <span style={{ color: "#2ecc71", fontStyle: "italic" }}>
              Machine Learning
            </span>
            , I’m keen on exploring how AI can be integrated into web
            applications to enhance interactivity and drive smarter analytics.
            Combining my web development expertise with my machine learning
            skills, I’m eager to work on projects that push the boundaries of
            technology. Whether it’s designing dynamic user interfaces or
            building robust server-side solutions, I’m all about continuous
            learning and improvement.
          </p>
          <footer>
            <small>
              Feel free to reach out if you’re interested in collaboration or
              just to chat about tech!
            </small>
          </footer>
          <button className="btn btn-primary my-2">
            <NavLink to="/">Home</NavLink>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Unique;
