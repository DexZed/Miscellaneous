import React from "react";
const Footer : React.FC = () => {
  return <section className="flex">
        <footer className="footer bg-neutral text-neutral-content p-10 justify-around ">
          <aside>
            <h4 className="text-3xl font-bold">Gadget Heaven</h4><br />
            <p>Leading the way in cutting edge technology and innovations</p>
          </aside>
          <nav>
            <h6 className="footer-title">Services</h6>
            <a className="link link-hover">Product Support</a>
            <a className="link link-hover">Order Tracking</a>
            <a className="link link-hover">Shipping and delivery</a>
            <a className="link link-hover">Returns</a>
          </nav>
          <nav>
            <h6 className="footer-title">Company</h6>
            <a className="link link-hover">About us</a>
            <a className="link link-hover">Contact</a>
            <a className="link link-hover">Careers</a>
            <a className="link link-hover">Address</a>
          </nav>
          <nav>
            <h6 className="footer-title">Legal</h6>
            <a className="link link-hover">Terms of use</a>
            <a className="link link-hover">Privacy policy</a>
            <a className="link link-hover">Cookie policy</a>
          </nav>
        </footer>
      </section>;
}
export default Footer;  