import React from "react";

interface ProSelProps {
    setSelected: (category: string) => void;
    select: string;
  }
  
  const ProSel: React.FC<ProSelProps> = ({ setSelected, select }) => {
    return (
    <div>
      <ul className="menu bg-base-200 w-56 gap-3 rounded-lg">
        <li>
          <a className={select === 'All' ? 'active' : ''}
             onClick={() => setSelected('All')}>All</a>
        </li>
        <li>
          <a className={select === 'Laptops' ? 'active' : ''} onClick={() => setSelected('Laptops')}>Laptops</a>
        </li>
        <li>
          <a className={select === 'Phones' ? 'active' : ''} onClick={() => setSelected('Phones')}>Smart Phones</a>
        </li>
        <li>
          <a className={select === 'Smart Watches' ? 'active' : ''} onClick={() => setSelected('Smart Watches')}>Smart Watches</a>
        </li>
      </ul>
    </div>
  );
};

export default ProSel;
