import React, { useState } from "react";
import Products from "./Products";
import ProSel from "./ProSel";
import Prodes from "./Prodes";
import { Product } from './types';

const Pain: React.FC = () => {
  
  const [select, setSelected] = useState<string>('All');
   // const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const handleViewDetails = (product: Product) => {
    setSelectedProduct(product);
  };

  const handleBackToProducts = () => {
    setSelectedProduct(null);
  };

  return (
    <section className="mx-3">
      <h2 className="text-3xl text-center m-5">Expore Cutting Edge Tech</h2>
      <div className="flex gap-3">
        {selectedProduct ? (
          <Prodes product={selectedProduct} onBack={handleBackToProducts} />
        ) : (
          <>
            <ProSel setSelected={setSelected} select={select} />
            <Products select={select} onViewDetails={handleViewDetails} />
          </>
        )}
      </div>
    </section>
  );
};

export default Pain;
