import { Component, ReactNode } from 'react';
import { Outlet } from 'react-router-dom';

interface ErrorBoundaryProps {
    children?: ReactNode;
  }
  
class ErrorBoundary extends Component<ErrorBoundaryProps> {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    console.error("Error caught by ErrorBoundary:", error);
  }

  render() {
    if (this.state.hasError) {
      return <Outlet />; 
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
