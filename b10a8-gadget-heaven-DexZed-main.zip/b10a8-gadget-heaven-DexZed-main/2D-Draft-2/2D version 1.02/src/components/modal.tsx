// Modal.tsx
import React from 'react';
import { ModalProps } from './types';


const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title = "Hello!", message = "Action successful!" }) => {
  return (
    <dialog id="purchase_modal" className="modal modal-bottom sm:modal-middle" open={isOpen}>
      <div className="modal-box flex flex-col">
        <img src="./images/Group.png" alt="group logo" className='aspect-square w-10 place-self-center m-2'/>
        <h3 className="font-bold text-lg text-center">{title}</h3>
        <p className="py-4 text-center">{message}</p>
        <div className="modal-action">
          <button className="btn btn-success btn-outline" onClick={onClose}>Close</button>
        </div>
      </div>
    </dialog>
  );
};

export default Modal;
