import React from "react";
import { CardsProps } from "./types";

const Card: React.FC<CardsProps> = ({ product }) => {
  return (
    <>
      <div className="flex justify-center">
      <img src={product.product_image} alt={product.product_title} className="w-[200px] rounded-xl m-5"/>
      <div className="flex flex-col translate-y-10">
        <h3 className="font-bold text-xl m-2">{product.product_title}</h3>
        <p className="m-2 text-lg">{product.description}</p>
        <p className="font-bold m-2">{product.price}</p>
      </div>
      </div>
      {/* //////////////////////////////////////////////////////////////// */}
     
    </>
  );
};

export default Card;
