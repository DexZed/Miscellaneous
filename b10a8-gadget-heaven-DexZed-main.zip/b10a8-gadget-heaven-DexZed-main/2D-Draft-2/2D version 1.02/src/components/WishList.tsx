import React from "react";
import { useGlobalContext } from "./Global";
import Card from "./card";
import { Product } from "./types";

const WishList: React.FC = () => {
  const { wishlistItems, removeItem, addToCart } = useGlobalContext();
  const handleAddToCart = (product: Product) => {
    addToCart(product);
  };
  return (
    <>
      <div>
        <h2 className="text-2xl font-bold text-center m-5">Wish List</h2>
      </div>
      <div className="wish-list cart flex flex-col mx-60 gap-2 my-3">
        {wishlistItems.map((product) => (
          <div
            key={product.product_id}
            className="flex border-2 rounded-xl shadow-md pr-5"
          >
            <Card product={product} />
            <button
              className="btn btn-secondary btn-outline mx-5 place-self-center"
              onClick={() => handleAddToCart(product)}
            >
              add to cart{" "}
            </button>
            <button
              className="btn btn-error btn-outline place-self-center"
              onClick={() => removeItem(product.product_id, "wishlist")}
            >
              Remove
            </button>
          </div>
        ))}
      </div>
    </>
  );
};

export default WishList;
