// types.ts

// Define the Product interface
export interface Product {
  product_id: string;
  product_title: string;
  product_image: string;
  category: string;
  price: number;
  description: string;
  Specification: string[];
  availability: boolean;
  rating: number;
}

// Define the ProductsProps interface
export interface ProductsProps {
  select: string;
  onViewDetails: (product: Product) => void;
}

// Define the ProdesProps interface for the Product Details component
export interface ProdesProps {
  product: Product;
  onBack: () => void;
  addToCart?: (product: Product) => void;
  addToWishList?: (product: Product) => void;
}
export interface CardsProps {
  product: Product;
}
export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  message?: string;
}
