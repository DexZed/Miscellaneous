import React from 'react'
import { Helmet } from 'react-helmet-async';
import { useLocation } from 'react-router-dom';

const Head:React.FC = () => {

    const location = useLocation();
    type RoutePaths = "/" | "/dashboard" | "/statistics" | "/about";

  // Define metadata for each route
  const metadata: Record<RoutePaths, { title: string; description: string; favicon: string }> = {
    "/": {
      title: "Home - Gadget Works",
      description: "Welcome to the Home page of My Website",
      favicon: "./images/home.svg",
    },
    "/dashboard": {
      title: "Dashboard - Your Purchase Information",
      description: "Overview of your purchase information",
      favicon: "./images/dash.svg",
    },
    "/statistics": {
      title: "Statistics - Price vs Quantity",
      description: "Explore detailed statistics and insights",
      favicon: "./images/stats.jpg",
    },
    "/about": {
      title: "About Us",
      description: "Tell us about your queries and information",
      favicon: "./images/dash.webp",
    },
  };

  // Get metadata based on the current path
  const currentMeta = metadata[location.pathname as RoutePaths] || {
    title: "Gadgets Heaven",
    description: "Welcome to My Gadgets",
    favicon: "./images/stats.jpg",
  };

  return (
    <Helmet>
      <title>{currentMeta.title}</title>
      <meta name="description" content={currentMeta.description} />
      <link rel="icon" type="image/svg+xml+jpg" href={currentMeta.favicon} />
      {/* Add more meta tags or links as needed */}
    </Helmet>
  )
}

export default Head