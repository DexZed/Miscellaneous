import React, { useState } from "react";
import { ProdesProps } from "./types";
import { useGlobalContext } from "./Global";
import Alert from "./Alert";

const Prodes: React.FC<ProdesProps> = ({ product, onBack }) => {
  const { addToCart, addToWishlist, isInWishlist } = useGlobalContext();
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [showAlert, setShowAlert] = useState<boolean>(false);

  const handleAddToCart = () => {
    addToCart(product);
    setAlertMessage("Item added to cart!"); // Set alert message
    setShowAlert(true); // Show the alert
    setTimeout(() => {
      setShowAlert(false); // Hide alert after 3 seconds
    }, 2000);
  };

  const handleAddToWishlist = () => {
    if (!isInWishlist(product.product_id)) {
      addToWishlist(product);
      setAlertMessage("Item added to wishlist!"); // Set alert message
      setShowAlert(true); // Show the alert
      setTimeout(() => {
        setShowAlert(false); // Hide alert after 3 seconds
      }, 2000);
    } else {
      setAlertMessage("Item is already in wishlist!"); // Set alert message if already in wishlist
      setShowAlert(true); // Show the alert
      setTimeout(() => {
        setShowAlert(false); // Hide alert after 3 seconds
      }, 2000);
    }
  };

  return (
    <>
    <div className="flex flex-col">
    <div className="place-self-center translate-x-40">
        {showAlert && <Alert message={alertMessage!} />}{" "}
      </div>
      <div className="card lg:card-side bg-base-100 shadow-xl">
        <figure>
          <img
            src={product.product_image}
            alt={product.product_title}
            className="aspect-square w-1/2 rounded-3xl"
            loading="lazy"
          />
        </figure>
        <div className="card-body">
          <h2 className="card-title text-3xl">{product.product_title}</h2>
          <p className="text-md font-bold">${product.price}</p>
          <p className="text-md text-grey-500">{product.description}</p>
          <h4 className="text-xl font-bold">Specifications</h4>
          <ul>
            {product.Specification.map((spec, index) => (
              <li key={index}>{spec}</li>
            ))}
          </ul>
          <h4 className="text-xl font-bold">Rating</h4>
          <div className="flex justify-items-center">
            <span>
              <div className="rating gap-1">
                <input
                  type="radio"
                  name="rating-3"
                  className="mask mask-heart bg-red-400"
                />
                <input
                  type="radio"
                  name="rating-3"
                  className="mask mask-heart bg-orange-400"
                  defaultChecked
                />
                <input
                  type="radio"
                  name="rating-3"
                  className="mask mask-heart bg-yellow-400"
                />
                <input
                  type="radio"
                  name="rating-3"
                  className="mask mask-heart bg-lime-400"
                />
                <input
                  type="radio"
                  name="rating-3"
                  className="mask mask-heart bg-green-400"
                />
              </div>
            </span>
            <span className="m-3 p-1 place-self-center -translate-y-4">
              {product.rating}
            </span>
          </div>
          <div className="card-actions justify-end">
            <button
              className="btn btn-accent btn-outline"
              onClick={handleAddToCart}
            >
              Add to Cart{" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
                />
              </svg>
            </button>
            <button
              type="button"
              className="btn btn-outline btn-secondary"
              onClick={handleAddToWishlist}
              disabled={isInWishlist(product.product_id)}
            >
              <img
                src="../images/heart.png"
                alt="heart icon"
                className="aspect-square h-5"
              />
            </button>
            <button onClick={onBack} className="btn btn-warning">
              Back to Products
            </button>
          </div>
        </div>
      </div>
    </div>
      
    </>
  );
};

export default Prodes;
