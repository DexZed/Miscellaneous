import React from "react";
import { Link } from "react-router-dom";

const Banner: React.FC = () => {
  return (
    <>
      <div className="hero bg-[#9538E2] min-h-screen">
        <div className="hero-content text-center">
          <div className="max-w-md">
            <h1 className="text-3xl font-bold text-white">
              Upgrade Your Tech Accessorize with Gadget Heaven Accessories
            </h1>
            <p className="py-6 text-white">
              Explore the latest gadgets that will take your experience to the
              next level. From smart devices to the coolest accessories, we have
              it all!
            </p>
            <button className="btn btn-neutral btn-outline bg-white text-black rounded-full w-1/2">
              <Link to="/dashboard">Shop Now</Link>
            </button>
          </div>
        </div>
      </div>
      <div className="flex justify-center -translate-y-44">
        <div className="w-3/4 border-8 p-5 border-white rounded-3xl bg-white/30">
          <img
            src="./images/banner.jpg"
            alt="banner"
            className="aspect-video rounded-3xl"
          />
        </div>
      </div>
    </>
  );
};

export default Banner;
