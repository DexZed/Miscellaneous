import React, { useState } from "react";
import Card from "./card";
import { useGlobalContext } from "./Global";
import Modal from "./modal";
import { useNavigate } from "react-router-dom";

const Cart: React.FC = () => {
  const { cartItems, removeItem, setCartItems } = useGlobalContext();
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState({
    title: "",
    message: "",
  });

  const totalPrice = cartItems.reduce((sum, item) => sum + item.price, 0);

  const sortByPrice = () => {
    const sortedItems = [...cartItems].sort((a, b) => b.price - a.price);
    setCartItems(sortedItems);
  };
  const navigate = useNavigate();
  const handlePurchase = () => {
    if (cartItems.length === 0) {
      setModalMessage({
        title: "No Items Selected",
        message: "Please select items to purchase.",
      });
      setShowModal(true);
      return;
    }
    setModalMessage({
      title: "Purchase Successful!",
      message: `Your items have been purchased for a total of ${totalPrice}$. Thank you!`,
    });
    setShowModal(true);
    setCartItems([]); // Clear cart
  };
  const handleModalClose = () => {
    setShowModal(false);
    navigate("/"); // Redirect to Home page
  };

  return (
    <>
      <div className="flex justify-around m-5">
        <h3 className="font-bold text-3xl">Cart</h3>
        <p className="font-bold text-xl place-self-center">Total price: ${totalPrice.toFixed(2)}</p>
        <div className="flex gap-2">
        <button type="button" className="btn btn-accent btn-outline" onClick={sortByPrice}>
          Sort by price
        </button>
        <button
          type="button"
          className="btn btn-secondary btn-outline"
          onClick={handlePurchase}
          disabled={totalPrice === 0}
        >
          Purchase
        </button>
        </div>
      </div>
      <div className="cart flex flex-col mx-60 gap-2 ">
        {cartItems.map((product) => (
          <div key={product.product_id} className="grid grid-cols-2 justify-items-center border-2 rounded-xl shadow-md">
            <Card product={product} />
            <button
              className="btn btn-error btn-outline place-self-center"
              onClick={() => removeItem(product.product_id, "cart")}
            >
              Remove
            </button>
          </div>
        ))}
      </div>
      <Modal
        isOpen={showModal}
        title={modalMessage.title}
        message={modalMessage.message}
        onClose={handleModalClose}
      />
    </>
  );
};

export default Cart;
