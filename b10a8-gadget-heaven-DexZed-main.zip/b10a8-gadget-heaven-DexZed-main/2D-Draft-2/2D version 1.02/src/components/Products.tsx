import React, { useState, useEffect } from "react";
import { Product, ProductsProps } from "./types";
import data from "../data/data.json";

const Products: React.FC<ProductsProps> = ({ select, onViewDetails }) => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setProducts(data);
      } catch (error) {
        console.error("Error fetching products data:", error);
      }
    };

    fetchData();
  }, []);
  const filteredProducts =
    select === "All"
      ? products
      : products.filter((product) => product.category === select);
  return (
    <>
      <div className="grid grid-cols-3 gap-5">
        {filteredProducts.map((product) => (
          <div className="card bg-base-100 w-96 shadow-xl">
          <figure className="mt-10 ">
            <img
              src={product.product_image}
              alt={product.product_title}
              className="aspect-square w-1/2 rounded-lg"
            />
          </figure>
          <div key={product.product_id} className="card-body">
            <h2 className="card-title">{product.product_title}</h2>
            <p>${product.price}</p>
            <div className="card-actions justify-center">
              <button
                className="btn btn-accent btn-outline"
                onClick={() => onViewDetails(product)}
              >
                View Details
              </button>
            </div>
          </div>
        </div>
        ))}
      </div>
      
    </>
  );
};

export default Products;
