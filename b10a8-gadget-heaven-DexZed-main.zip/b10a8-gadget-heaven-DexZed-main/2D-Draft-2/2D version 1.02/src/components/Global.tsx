import React, { createContext, useContext, useState } from "react";
import { Product } from "./types";
import { Dispatch, SetStateAction } from "react";

interface GlobalContextProps {
  cartItems: Product[];
  wishlistItems: Product[];
  addToCart: (product: Product) => void;
  addToWishlist: (product: Product) => void;
  removeItem: (productId: string, listType: "cart" | "wishlist") => void;
  setCartItems: Dispatch<SetStateAction<Product[]>>;
  cartItemCount: number;
  wishlistItemCount: number;
  isInWishlist: (productId: string) => boolean;
}

// Create context with default values
const GlobalContext = createContext<GlobalContextProps | undefined>(undefined);

export const GlobalProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [cartItems, setCartItems] = useState<Product[]>([]);
  const [wishlistItems, setWishlistItems] = useState<Product[]>([]);

  // Add to cart function
  const addToCart = (product: Product) => {
    setCartItems((prevItems) => [...prevItems, product]);
  };

  // Add to wishlist function
  const addToWishlist = (product: Product) => {
    // Check if product is already in wishlist
    const isAlreadyInWishlist = wishlistItems.some(
      (item) => item.product_id === product.product_id
    );

    if (!isAlreadyInWishlist) {
      setWishlistItems((prevItems) => [...prevItems, product]);
    }
  };
  const isInWishlist = (productId: string): boolean => {
    return wishlistItems.some((item) => item.product_id === productId);
  };
  const removeItem = (productId: string, listType: "cart" | "wishlist") => {
    if (listType === "cart") {
      setCartItems((prevItems) =>
        prevItems.filter((item) => item.product_id !== productId)
      );
    } else if (listType === "wishlist") {
      setWishlistItems((prevItems) =>
        prevItems.filter((item) => item.product_id !== productId)
      );
    }
  };
  const cartItemCount = cartItems.length;
  const wishlistItemCount = wishlistItems.length;
  // Context value with cart and wishlist functionality
  const contextValue: GlobalContextProps = {
    cartItems,
    wishlistItems,
    addToCart,
    addToWishlist,
    removeItem,
    setCartItems,
    cartItemCount,
    wishlistItemCount,
    isInWishlist,
  };

  return (
    <GlobalContext.Provider value={contextValue}>
      {children}
    </GlobalContext.Provider>
  );
};

// Custom hook to use global context
export const useGlobalContext = (): GlobalContextProps => {
  const context = useContext(GlobalContext);
  if (context === undefined) {
    throw new Error("useGlobalContext must be used within a GlobalProvider");
  }
  return context;
};
